/*
*
* Authors: James Hall and Nicola Willis
* Team: NegasonicStudentWarhead
*
*/
var config = {};

config.portNo = 3000;

config.twitter = {
	consumer_key: 'dtKIsNlfcoMSFYG2GtrrgIeC6',
	consumer_secret: 'Z0odfical3CpTTnzBuF0xYIC4ArLB7d1KU8wrun53XtXKLkDIK',
	access_token: '703233270037811201-Qv8OaglDoBgFjvBfgMALF7IogGt6HoA',
	access_token_secret: 'NRk6oTICWLfAYaoLEDXuyq1AHmx4SaKEcLCR7XsnmHsnU'
};

config.mysql = {
      host     : 'localhost',
      port     : '3306',
      user     : 'James',
      password : '8A2b26be8d',
      database : 'intelligentwebassignment',
      charset  : 'utf8mb4'
};

module.exports = config;